#!/usr/bin/env bash 
path=`pwd`
docker run -d --net host --name mect-redis\
     -p 6379:6379 \
     -e TZ=Asia/Shanghai \
     --restart=always \
     -v ${path}/redis.conf:/etc/redis/redis.conf \
     redis:5.0.7 \
     redis-server /etc/redis/redis.conf
exit
